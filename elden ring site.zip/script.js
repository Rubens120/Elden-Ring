//navbar function
function navbarFunction() {
  var x = document.getElementById("navbar-id");
  if (x.className === "navbars") {
    x.className += "responsive";
  } else {
    x.className = "navbars";
  }
}

// function heart button
// const heart = document.querySelector(".heart");
// const heartColor = document.querySelector(".heartcolor")
// const heartClick = document.querySelector(".heartcolor")

// heart.addEventListener('click', () =>{
// heart.classList.add("heartcolor");
// });
// function heartfunction(){
// var h = document.getElementById("heartbutton");
// if (h.className === "heart"){

// }
// }
// function heartClick(){
// var x = document.getElementById("heartbutten")
// if (x === x){
//   document.getElementById("heartbutton").classList.add("heartcolor")
// }
// else {
//   document.getElementById("heartbutton").classList.remove("heartcolor")
// }
// }


function heartToggle() {
  var element = document.getElementById("heartbutton");
  element.classList.toggle("heartcolor");
}

// document.getElementsByClassName("heart")
// function heartfunction(){
//   var heart = document.getElementsByClassName("heart");
//   if (heart.style.backroundcolor == "red") {
//     heart.style.backroundcolor == "white";
//   }
//   else {
//     heart.style.backroundcolor == "white";
//   }
// }

// art images function
// const rightArrow = document.querySelector(".right-arrow");
// const leftArrow = document.querySelector(".left-arrow");
// const imgs = document.querySelector(".first-image");

// rightArrow.addEventListener('click', () => {
// rightArrow.classList.add("clicked");
// leftArrow.classList.add("clicked");
// imgs.classList.add("clicked");
// });

// leftArrow.addEventListener('click', ()=>{
// rightArrow.classList.remove("clicked");
// leftArrow.classList.remove("clicked");
// imgs.classList.remove("clicked");
// });

// const artSlider = document.querySelector(".art-slider")
// firstImg = artSlider.querySelectorAll("img")[0];
// const arrows = document.querySelectorAll(".art-container i")

// let firstImgWidth = firstImg.clientWidth + 60;
//  const showHideIcons = () => {
//   arrows[0].style.display = artSlider.scrollLeft == 0 ? 'none' : 'block';
//   arrows[1].style.display = artSlider.scrollLeft == 0 ? 'none' : 'block';
//  }
// // const showHideIcons = () => {
// //   if (artSlider.scrollLeft == 0){
// //     arrows[0].style.display = "none";
// //   }else {
// //     arrows[0].style.display = "block";
// //   }
// //   setTimeout(() => showHideIcons(), 60);
// // }

// arrows.forEach(icon => {
//   icon.addEventListener("click", () =>{
//     if (icon.id == 'left'){
//       artSlider.scrollLeft -= firstImgWidth;
//     } else {
//       artSlider.scrollLeft += firstImgWidth;
//     }
//     showHideIcons();
//   });
// });

const carousel = document.querySelector(".art-slider"),
firstImg = carousel.querySelectorAll("img")[0],
arrowIcons = document.querySelectorAll(".art-container i");

let isDragStart = false, isDragging = false, prevPageX, prevScrollLeft, positionDiff;

const showHideIcons = () => {
    // showing and hiding prev/next icon according to carousel scroll left value
    let scrollWidth = carousel.scrollWidth - carousel.clientWidth; // getting max scrollable width
    arrowIcons[0].style.display = carousel.scrollLeft == 0 ? "none" : "block";
    arrowIcons[1].style.display = carousel.scrollLeft == scrollWidth ? "none" : "block";
}

arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg.clientWidth + 30; // getting first img width & adding 14 margin value
        // if clicked icon is left, reduce width value from the carousel scroll left else add to it
        carousel.scrollLeft += icon.id == "left" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons(), 60); // calling showHideIcons after 60ms
    });
});

const autoSlide = () => {
    // if there is no image left to scroll then return from here
    if(carousel.scrollLeft - (carousel.scrollWidth - carousel.clientWidth) > -1 || carousel.scrollLeft <= 0) return;

    positionDiff = Math.abs(positionDiff); // making positionDiff value to positive
    let firstImgWidth = firstImg.clientWidth + 14;
    // getting difference value that needs to add or reduce from carousel left to take middle img center
    let valDifference = firstImgWidth - positionDiff;

    if(carousel.scrollLeft > prevScrollLeft) { // if user is scrolling to the right
        return carousel.scrollLeft += positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
    }
    // if user is scrolling to the left
    carousel.scrollLeft -= positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
}

const dragStart = (e) => {
    // updatating global variables value on mouse down event
    isDragStart = true;
    prevPageX = e.pageX || e.touches[0].pageX;
    prevScrollLeft = carousel.scrollLeft;
}

const dragging = (e) => {
    // scrolling images/carousel to left according to mouse pointer
    if(!isDragStart) return;
    e.preventDefault();
    isDragging = true;
    carousel.classList.add("dragging");
    positionDiff = (e.pageX || e.touches[0].pageX) - prevPageX;
    carousel.scrollLeft = prevScrollLeft - positionDiff;
    showHideIcons();
}

const dragStop = () => {
    isDragStart = false;
    carousel.classList.remove("dragging");

    if(!isDragging) return;
    isDragging = false;
    autoSlide();
}

carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("touchstart", dragStart);

document.addEventListener("mousemove", dragging);
carousel.addEventListener("touchmove", dragging);

document.addEventListener("mouseup", dragStop);
carousel.addEventListener("touchend", dragStop);


// function characters
// let slideIndex = 1;
// showSlides(slideIndex);

// function plusSlides(n) {
// showSlides(slideIndex += n);
// }

// function showSlides(n) {
//   let i;
//   let slides = document.getElementsByClassName("Character-content");
//   if (n > slides.length) {slideIndex = 1}    
//   if (n < 1) {slideIndex = slides.length}
//   for (i = 0; i < slides.length; i++) {
//     slides[i].style.display = "none";  
//   }
//   if (window.innerWidth <= 768) {
//     slides[slideIndex - 1].style.display = "grid";
//   } else {
//     slides[slideIndex - 1].style.display = "flex";
//   }
// }
// window.addEventListener('resize', function () {
//   showSlides(slideIndex);
// }); 

let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
showSlides(slideIndex += n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("Character-content");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "flex";
}





