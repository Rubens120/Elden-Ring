//function heart button
const heart = document.querySelector(".heart");
const heartcolor = document.querySelector(".heartcolor")
const heartclick = document.querySelector(".heartcolor")
heartclick

heart.addEventListener('click', () =>{
heart.classList.add("heartcolor");
});


// art images function
const rightArrow = document.querySelector(".right-arrow");
const leftArrow = document.querySelector(".left-arrow");
const imgs = document.querySelector(".first-image");

rightArrow.addEventListener('click', () => {
rightArrow.classList.add("clicked");
leftArrow.classList.add("clicked");
imgs.classList.add("clicked");
});

leftArrow.addEventListener('click', ()=>{
rightArrow.classList.remove("clicked");
leftArrow.classList.remove("clicked");
imgs.classList.remove("clicked");
});


// function characters
let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
showSlides(slideIndex += n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("Character-content");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slides[slideIndex-1].style.display = "flex";
}




